package com.amazon.repository;

public class LoginRepository {

}
