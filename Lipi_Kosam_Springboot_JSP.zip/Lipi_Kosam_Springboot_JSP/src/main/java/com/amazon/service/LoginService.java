package com.amazon.service;

public class LoginService {

}
